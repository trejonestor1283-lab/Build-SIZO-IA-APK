package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SIZO IA Dark Backgrounds
val SizoBlack = Color(0xFF090C10)
val SizoSurface = Color(0xFF0F141C)
val SizoSurfaceVariant = Color(0xFF171E2B)
val SizoSurfaceElevated = Color(0xFF1F293A)

// SIZO IA Neon & Warm Orange Accents
val SizoOrangePrimary = Color(0xFFFF6B00)
val SizoOrangeBright = Color(0xFFFF851B)
val SizoOrangeLight = Color(0xFFFFA559)
val SizoOrangeAmber = Color(0xFFFFB866)
val SizoOrangeDark = Color(0xFFD95000)
val SizoOrangeSubtle = Color(0x26FF6B00)
val SizoOrangeGlow = Color(0x4DFF6B00)

// Text and UI states
val SizoTextWhite = Color(0xFFF8FAFC)
val SizoTextSecondary = Color(0xFF94A3B8)
val SizoTextMuted = Color(0xFF64748B)

val SizoBorder = Color(0x33FF6B00)
val SizoBorderLight = Color(0xFF263245)
val SizoStatusOnline = Color(0xFF10B981)
val SizoCardDark = Color(0xFF121722)
